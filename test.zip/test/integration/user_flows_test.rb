require 'test_helper'

class UserFlowsTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end

  test "should be able to login and browse" do
    # login via https
    https!
    get "users/index"
    assert_response :success

    post_via_redirect "posts/index", :username => "v", :password => "12345"
    assert_response :success

    get "/posts/comment"
    assert_response :success


  end


end
